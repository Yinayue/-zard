# recommender_user
基于java的用户协同推荐项目
参考:https://blog.csdn.net/cc_want/article/details/85001762

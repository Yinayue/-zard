package com.tarzan.recommend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecommendSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

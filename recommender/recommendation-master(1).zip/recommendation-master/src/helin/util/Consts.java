package helin.util;

/**
 * Consts.java
 * 
 * @description save some constants
 * 
 */
public class Consts {

	public final static int MAX_V_N = 150000;
	public final static int MAX_NUM = 1000;
	public final static int MAX_DEVIATION = 100;
	public final static float decIndex = (float) 0.2;

}

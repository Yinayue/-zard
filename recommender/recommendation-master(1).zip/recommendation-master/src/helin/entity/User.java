package helin.entity;

/**
 * User.java
 * 
 * @description basic information about user
 * 
 */
public class User {

	// user id
	public int userId;

	// user data
	public int userData;

}

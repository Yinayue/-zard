package helin.entity;

/**
 * Movie.java
 * 
 * @description basic information about movie
 * 
 */
public class Movie {

	// movie id
	public int movieId;

	// movie data
	public int movieData;

}
